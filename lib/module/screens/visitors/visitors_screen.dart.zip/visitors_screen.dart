import 'package:flutter/material.dart';
import 'package:highfly/config/constant/app_colors.dart';
import 'package:highfly/config/constant/const_assets.dart';
import 'package:highfly/module/global/widgets/custom_button.dart';
import '../../utils/responsive.dart';

class VisitorsScreen extends StatefulWidget {
  const VisitorsScreen({super.key});

  @override
  State<VisitorsScreen> createState() => _VisitorsScreenState();
}

class _VisitorsScreenState extends State<VisitorsScreen> {
  final List<Map<String, dynamic>> visitors = [
    {
      "id": "V001",
      "name": "John Smith",
      "phone": "+1 234 567 8900",
      "email": "john.smith@email.com",
      "project": "Sunrise Residency",
      "visitDate": "2024-01-15",
      "visitTime": "10:30 AM",
      "status": "Scheduled",
      "purpose": "Site Visit",
      "notes": "Interested in 2BHK apartment",
      "comments": "Interested in residential Properties, Interested in residential Properties, Interested in residential Properties, Interested in residential Properties, Interested in residential Properties"
    },
    {
      "id": "V002",
      "name": "Sarah Johnson",
      "phone": "+1 234 567 8901",
      "email": "sarah.j@email.com",
      "project": "Metro Complex",
      "visitDate": "2024-01-16",
      "visitTime": "2:00 PM",
      "status": "Completed",
      "purpose": "Final Inspection",
      "notes": "Ready for booking",
      "comments": "Interested in residential Properties"
    },
    {
      "id": "V003",
      "name": "Michael Brown",
      "phone": "+1 234 567 8902",
      "email": "m.brown@email.com",
      "project": "Sunrise Residency",
      "visitDate": "2024-01-17",
      "visitTime": "11:00 AM",
      "status": "Confirmed",
      "purpose": "Documentation",
      "notes": "Bringing loan documents",
      "comments": "Interested in residential Properties"
    },
    {
      "id": "V004",
      "name": "Emma Wilson",
      "phone": "+1 234 567 8903",
      "email": "emma.wilson@email.com",
      "project": "Metro Complex",
      "visitDate": "2024-01-18",
      "visitTime": "4:30 PM",
      "status": "Pending",
      "purpose": "Site Visit",
      "notes": "First time visitor",
      "comments": "Interested in residential Properties"
    },
  ];

  String selectedFilter = "All";
  final List<String> filterOptions = ["All", "Scheduled", "Confirmed", "Completed", "Pending"];

  @override
  Widget build(BuildContext context) {
    return Responsive(
      mobile: _buildMobileLayout(),
      tablet: _buildMobileLayout(),
      desktop: _buildDesktopLayout(),
    );
  }

  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Visitors",
            style: TextStyle(
              color: AppColors.primaryTextColor,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),

          CustomButton(
            onPressed: () {
              showAddVisitDialog(context);
            },
            width: 150,
            leadingWidget: Icon(Icons.add, size: 18,),
            text: "Add Visit", 
            textStyle: TextStyle(fontSize: 14),
          ),

          const SizedBox(height: 20),

          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              children: _getFilteredVisitors()
                  .map((visitor) => _buildMobileVisitorCard(visitor))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDesktopLayout() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Visitors Management",
                style: TextStyle(
                  color: AppColors.primaryTextColor,
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          Row(
            children: [
              CustomButton(
                onPressed: () {
                  showAddVisitDialog(context);
                },
                width: 150,
                leadingWidget: Icon(Icons.add, size: 18,),
                text: "Add Visit", 
                textStyle: TextStyle(fontSize: 14),
              ),
            ],
          ),

          const SizedBox(height: 24),

          _buildVisitorsTable(),
        ],
      ),
    );
  }

  Widget _buildMobileVisitorCard(Map<String, dynamic> visitor) {
    return GestureDetector(
      onTap: () => _showVisitorDetailDialog(visitor),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.grey[50],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[200]!),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.primaryTextColor),
                  image: DecorationImage(image: AssetImage(ImageAssets.highFlyLogo))
                ),
              ),
              const SizedBox(width: 16),
              
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      visitor["name"],
                      style: const TextStyle(
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    
                    Text(
                      visitor["project"],
                      style: const TextStyle(
                        color: AppColors.primaryTextColor,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    
                    Row(
                      children: [
                        Icon(
                          Icons.access_time,
                          size: 14,
                          color: Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          "${visitor["visitDate"]} at ${visitor["visitTime"]}",
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    
                    Text(
                      visitor["comments"],
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 11,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey[400],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVisitorsTable() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width / 3,
              height: 40,
              child: TextField(
                style: const TextStyle(fontSize: 14),
                decoration: InputDecoration(
                  hintText: "Search visitors...",
                  prefixIcon: const Icon(Icons.search, size: 20),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: ConstrainedBox(
              constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width - 40),
              child: DataTable(
                showCheckboxColumn: false,
                columnSpacing: 20,
                columns: const [
                  DataColumn(
                    label: Text(
                      "Project",
                      style: TextStyle(
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      "Visitor",
                      style: TextStyle(
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      "Date & Time",
                      style: TextStyle(color: AppColors.primaryTextColor),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      "Photo",
                      style: TextStyle(color: AppColors.primaryTextColor),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      "Comments",
                      style: TextStyle(color: AppColors.primaryTextColor),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      "Actions",
                      style: TextStyle(color: AppColors.primaryTextColor),
                    ),
                  ),
                ],
                rows: _getFilteredVisitors().map((visitor) {
                  return DataRow(
                    onSelectChanged: (selected) {
                      if (selected ?? false) {
                        _showVisitorDetailDialog(visitor);
                      }
                    },
                    cells: [
                      DataCell(
                        GestureDetector(
                          onTap: () => _showVisitorDetailDialog(visitor),
                          child: SizedBox(
                            width: 120,
                            child: Text(
                              visitor["project"],
                              style: const TextStyle(
                                color: AppColors.primaryTextColor,
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ),
                      DataCell(
                        GestureDetector(
                          onTap: () => _showVisitorDetailDialog(visitor),
                          child: SizedBox(
                            width: 100,
                            child: Text(
                              visitor["name"],
                              style: const TextStyle(color: AppColors.primaryTextColor),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ),
                      DataCell(
                        GestureDetector(
                          onTap: () => _showVisitorDetailDialog(visitor),
                          child: SizedBox(
                            width: 100,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  visitor["visitDate"],
                                  style: const TextStyle(
                                    color: AppColors.primaryTextColor,
                                    fontSize: 12,
                                  ),
                                ),
                                Text(
                                  visitor["visitTime"],
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      DataCell(
                        GestureDetector(
                          onTap: () => _showVisitorDetailDialog(visitor),
                          child: SizedBox(
                              height: 40,
                              width: 40,
                              child: Image.asset(ImageAssets.highFlyLogo)),
                        )
                      ),
                      DataCell(
                        GestureDetector(
                          onTap: () => _showVisitorDetailDialog(visitor),
                          child: SizedBox(
                            width: 120,
                            child: Text(
                              visitor["comments"],
                              style: const TextStyle(color: AppColors.primaryTextColor, fontSize: 12),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                            ),
                          ),
                        ),
                      ),
                      DataCell(
                        GestureDetector(
                          onTap: () => _showVisitorDetailDialog(visitor),
                          child: Container(
                            height: 25,
                            width: 70,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: AppColors.secondaryTextColor, width: 0.5),
                              borderRadius: BorderRadius.all(Radius.circular(4))
                            ),
                            child: Center(child: Text("View Detail", style: TextStyle(color: AppColors.primaryTextColor, fontSize: 10),)),
                          ),
                        )
                      ),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredVisitors() {
    if (selectedFilter == "All") {
      return visitors;
    }
    return visitors.where((visitor) => visitor["status"] == selectedFilter).toList();
  }

  void _showVisitorDetailDialog(Map<String, dynamic> visitor) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9 > 600 
                ? 600 
                : MediaQuery.of(context).size.width * 0.9,
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.8,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor.withOpacity(0.1),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: AppColors.primaryColor.withOpacity(0.2),
                        backgroundImage: AssetImage(ImageAssets.highFlyLogo),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              visitor["name"],
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryTextColor,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Visitor ID: ${visitor["id"]}",
                              style: TextStyle(
                                fontSize: 14,
                                color: AppColors.secondaryTextColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.close),
                        color: AppColors.secondaryTextColor,
                      ),
                    ],
                  ),
                ),
                
                Flexible(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getStatusColor(visitor["status"]).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: _getStatusColor(visitor["status"]),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            visitor["status"],
                            style: TextStyle(
                              color: _getStatusColor(visitor["status"]),
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 24),
                        
                        _buildDetailSection(
                          title: "Contact Information",
                          icon: Icons.contact_phone,
                          children: [
                            _buildDetailRow("Phone", visitor["phone"], Icons.phone),
                            _buildDetailRow("Email", visitor["email"], Icons.email),
                          ],
                        ),
                        
                        const SizedBox(height: 20),
                        
                        _buildDetailSection(
                          title: "Visit Information",
                          icon: Icons.event,
                          children: [
                            _buildDetailRow("Project", visitor["project"], Icons.business),
                            _buildDetailRow("Visit Date", visitor["visitDate"], Icons.calendar_today),
                            _buildDetailRow("Visit Time", visitor["visitTime"], Icons.access_time),
                            _buildDetailRow("Purpose", visitor["purpose"], Icons.assignment),
                          ],
                        ),
                        
                        const SizedBox(height: 20),
                        
                        _buildDetailSection(
                          title: "Additional Information",
                          icon: Icons.info_outline,
                          children: [
                            _buildDetailRow("Notes", visitor["notes"], Icons.note),
                            const SizedBox(height: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.comment,
                                      size: 18,
                                      color: AppColors.secondaryTextColor,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      "Comments:",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.primaryTextColor,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppColors.textFieldBGColor,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: AppColors.alternateColor,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    visitor["comments"],
                                    style: TextStyle(
                                      color: AppColors.primaryTextColor,
                                      fontSize: 14,
                                      height: 1.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.textFieldBGColor,
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(16),
                      bottomRight: Radius.circular(16),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pop();
                            _makePhoneCall(visitor["phone"]);
                          },
                          icon: const Icon(Icons.call, size: 18),
                          label: const Text("Call"),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.green,
                            side: const BorderSide(color: Colors.green),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pop();
                            _sendEmail(visitor["email"]);
                          },
                          icon: const Icon(Icons.email, size: 18),
                          label: const Text("Email"),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.blue,
                            side: const BorderSide(color: Colors.blue),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pop();
                            _editVisitor(visitor);
                          },
                          icon: const Icon(Icons.edit, size: 18),
                          label: const Text("Edit"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryColor,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDetailSection({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              size: 20,
              color: AppColors.primaryColor,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppColors.primaryTextColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: AppColors.alternateColor,
              width: 1,
            ),
          ),
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }

  Widget _buildDetailRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            size: 18,
            color: AppColors.secondaryTextColor,
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: Text(
              "$label:",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: AppColors.primaryTextColor,
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: TextStyle(
                color: AppColors.primaryTextColor,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'scheduled':
        return Colors.blue;
      case 'confirmed':
        return Colors.green;
      case 'completed':
        return Colors.grey;
      case 'pending':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  void _makePhoneCall(String phoneNumber) {
    debugPrint("Calling: $phoneNumber");
  }

  void _sendEmail(String email) {
    debugPrint("Sending email to: $email");
  }

  void _editVisitor(Map<String, dynamic> visitor) {
    debugPrint("Editing visitor: ${visitor['name']}");
  }

  void showAddVisitDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return _AddVisitDialog();
      },
    );
  }
}

class _AddVisitDialog extends StatefulWidget {
  @override
  State<_AddVisitDialog> createState() => _AddVisitDialogState();
}

class _AddVisitDialogState extends State<_AddVisitDialog> {
  final _formKey = GlobalKey<FormState>();
  String? selectedProject;
  String? visitorName;
  String? selectedAgent;
  String? comments;

  final List<String> projects = ["Green Valley Estates", "Sunrise Residency", "Metro"];
  final List<String> agents = ["Sarah Johnson", "Michael Smith", "Emily Brown"];

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 500),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Add Visit",
                      style: TextStyle(
                        fontSize: 15,
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, size: 20,),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Divider(color: AppColors.secondaryTextColor, height: 0.2,),
                const SizedBox(height: 8),

                _buildCustomDropdown(
                  label: "Project Name *",
                  value: selectedProject,
                  items: projects,
                  onChanged: (value) {
                    setState(() {
                      selectedProject = value;
                    });
                  },
                  validator: (value) => value == null ? "Please select a project" : null,
                ),
                const SizedBox(height: 12),

                _buildCustomTextField(
                  label: "Visitor Name *",
                  onChanged: (value) => visitorName = value,
                  validator: (value) => value == null || value.isEmpty ? "Enter visitor name" : null,
                ),
                const SizedBox(height: 12),

                _buildCustomDropdown(
                  label: "Assign Agent *",
                  value: selectedAgent,
                  items: agents,
                  onChanged: (value) {
                    setState(() {
                      selectedAgent = value;
                    });
                  },
                  validator: (value) => value == null ? "Please select an agent" : null,
                ),
                const SizedBox(height: 12),

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Visitor Photo *", style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),),
                    const SizedBox(height: 6),
                    OutlinedButton.icon(
                      onPressed: () {},
                      icon: Icon(Icons.attach_file),
                      label: Text("Choose File"),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                _buildCustomTextField(
                  label: "Comments",
                  maxLines: 3,
                  onChanged: (value) => comments = value,
                ),
                const SizedBox(height: 20),

                // Row(
                //   children: [
                //     Expanded(
                //       child: OutlinedButton(
                //         onPressed: () => Navigator.pop(context),
                //         child: Text("Cancel"),
                //       ),
                //     ),
                //     const SizedBox(width: 10),
                //     Expanded(
                //       child: ElevatedButton(
                //         style: ElevatedButton.styleFrom(
                //           backgroundColor: Colors.orange,
                //         ),
                //         onPressed: () {
                //           if (_formKey.currentState!.validate()) {
                //             print("Project: $selectedProject");
                //             print("Visitor: $visitorName");
                //             print("Agent: $selectedAgent");
                //             print("Comments: $comments");
                //             Navigator.pop(context);
                //           }
                //         },
                //         child: Text("Save Visit"),
                //       ),
                //     ),
                //   ],
                // ),

                Expanded(
                  child: GestureDetector(
                    onTap: (){
                      Navigator.pop(context);
                    },
                    child: Container(
                      height: 40,
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColors.secondaryTextColor, width: 0.5),
                        borderRadius: BorderRadius.all(Radius.circular(5))
                      ),
                      child: Center(child: Text("Cancel", style: TextStyle(color: AppColors.primaryTextColor, fontWeight: FontWeight.w700),)),
                    ),
                  )
                ),

                SizedBox(
                  height: 10,
                ),

                CustomButton(
                    height: 40,
                    text: "Save Visit")
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCustomDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(width: 4),
            if (label.contains('*'))
              Container(
                width: 5,
                height: 5,
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        DropdownButtonFormField<String>(
          value: value,
          validator: validator,
          decoration: InputDecoration(
            isDense: true,
            fillColor: Colors.white,
            filled: true,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppColors.primaryTextColor,
                width: 0.5,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: Colors.black26,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppColors.primaryTextColor,
                width: 1,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: Colors.red,
                width: 1.2,
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: Colors.red,
                width: 1.5,
              ),
            ),
          ),
          items: items.map((item) {
            return DropdownMenuItem<String>(
              value: item,
              child: Text(
                item,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.black,
                ),
              ),
            );
          }).toList(),
          onChanged: onChanged,
          style: const TextStyle(
            fontSize: 14,
            color: Colors.black,
          ),
          icon: const Icon(
            Icons.arrow_drop_down,
            color: AppColors.secondaryTextColor,
          ),
        ),
      ],
    );
  }

  Widget _buildCustomTextField({
    required String label,
    String? Function(String?)? validator,
    ValueChanged<String>? onChanged,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(width: 4),
            if (label.contains('*'))
              Container(
                width: 5,
                height: 5,
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        TextFormField(
          validator: validator,
          onChanged: onChanged,
          maxLines: maxLines,
          style: const TextStyle(
            fontSize: 14,
            color: Colors.black,
          ),
          cursorColor: AppColors.primaryTextColor,
          decoration: InputDecoration(
            isDense: true,
            fillColor: Colors.white,
            filled: true,
            contentPadding: EdgeInsets.symmetric(
              horizontal: 12,
              vertical: maxLines > 1 ? 12 : 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppColors.primaryTextColor,
                width: 0.5,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: Colors.black26,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppColors.primaryTextColor,
                width: 1,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: Colors.red,
                width: 1.2,
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: Colors.red,
                width: 1.5,
              ),
            ),
          ),
        ),
      ],
    );
  }
}